#!/bin/bash
mpirun -np 16 hybrid 1000